import matplotlib.pyplot as plt
import numpy as np

xAxis = np.array(range(1,95))

terms = ["delivery_prob", "overhead_ratio", "End-to-End delay"]


numOfSamples = 25
skip = 1

legend = range(2,numOfSamples+1,skip);
legend.append("epidemic")
legend.append("prophet")
legend = [str(i) for i in legend]

for term in terms:

	for i in range(2,numOfSamples+1,skip):

		
		filename = "NewRouter_MessageStatsReport_" + str(i) + ".txt"
		f = open(filename, "r")
	
		yAxis = []

		for line in f:
			values = line.split(':')
			if(values[0] == term):
				yAxis.append(float(values[1].strip()))

		f.close()
		plt.plot(xAxis,yAxis)


	extraFiles = ["EpidemicRouter_MessageStatsReport_2.txt", "ProphetRouter_MessageStatsReport_3.txt"];

	for filename in extraFiles:

		f = open(filename, "r")

		yAxis = []

		for line in f:
			values = line.split(':')
			if(values[0] == term):
				yAxis.append(float(values[1].strip()))

		f.close()
		plt.plot(xAxis,yAxis)


	plt.ylabel(term)
	plt.xlabel('time in hours')
	plt.legend(legend, loc='lower right')
	outputFile = term + str(skip) + ".png"
	plt.savefig(outputFile)
	plt.gcf().clear()




	